# VISU VARIANTU PALYGINIMAS

## 1. Modeliai per API (protingiausi, reikia paskyros)

| Teikėjas | Nemokamai | Kortelė | Patikrinta |
|---|---|---|---|
| **Groq** | 30 uzkl./min · 1 000/d · 8 000 zetonu/min · **200 000 zetonu/d** | ne | PATIKRINTA |
| **Gemini** | Free tier, limitai per modeli, RPD vidurnakti PT | ne | PATIKRINTA (kad yra) |
| **OpenRouter** | 20 uzkl./min · **50/d be kredito** · 1 000/d nuo $10 | ne | PATIKRINTA |
| Mistral | nemokamas planas, apimtis neaiski | ne | NEPATIKRINTA |
| Cerebras | $5 kreditas, gana per 30 d | TAIP | NEPATIKRINTA |
| Cloudflare Workers AI | ~10 000 neuronu/d | ne | NEPATIKRINTA |
| Cohere | ~1 000 API kvietimu/men bandymams | ne | NEPATIKRINTA |
| Together/Fireworks/SiliconFlow/Nebius/KIE/Bedrock/Zhipu | vienkartiniai $1-200 | dazn. ne | NEPATIKRINTA |

## 2. Agentai (DI, kuris pats narso)

| Sprendimas | Kas tai | Nemokamai | Reikia rakto | Patikrinta |
|---|---|---|---|---|
| **Browser Use** | atviro kodo agentas, valdo narsykle | kodas 100 % | TAIP (Groq) | PATIKRINTA 0.13.14, Python 3.11+ |
| Firecrawl | skrebimas + „gyvos" sesijos | ~1 000 kreditu/men | ne | NEPATIKRINTA |
| Nanobrowser | Chrome ple tinys | 100 % | TAIP | NEPATIKRINTA |
| OpenHands | inzinieriaus agentas (Docker) | kodas | TAIP | NEPATIKRINTA |
| BetterClaw | hosted agentas | 1 agentas amzinai | TAIP (BYOK) | NEPATIKRINTA |

## 3. Paieska (agento „akys")

| Teikėjas | Nemokamai | Patikrinta |
|---|---|---|
| Tavily | ~1 000 kreditu/men | NEPATIKRINTA (svetaine skaiciu neskelbia) |
| Exa | ~$10/men | NEPATIKRINTA |
| Serper | ~2 500 uzklausu | NEPATIKRINTA |
| Firecrawl search | ~1 000 kreditu/men | NEPATIKRINTA |

## 4. Vietiniai modeliai

| Modelis | Dydis | RAM | Greitis siame PC | Patikrinta |
|---|---|---|---|---|
| qwen2.5:3b (Q4_K_M) | **1,9 GB** | ~3 GB | ~5-10 zetonu/s | PATIKRINTA |
| llama3.2:3b | ~2 GB | ~3 GB | panasus | is dalies |
| 7B+ | 4-5 GB+ | 6 GB+ | netelpa | - |

## Isvada

1. **Protas** = Groq (200 k zetonu/d).
2. **Offline** = Ollama + qwen2.5:3b (1,9 GB).
3. **Rankos** = Browser Use (jau idiegtas) + Groq raktas.
4. **Akys** = Tavily (kai prireiks).
