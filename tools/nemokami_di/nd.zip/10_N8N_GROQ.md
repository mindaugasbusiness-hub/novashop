# KAIP PRIJUNGTI GROQ PRIE N8N

## 1. Raktas
`C:\Users\M\CLINE\ai-stack\.env` -> eilute:
    GROQ_API_KEY=gsk_...

(n8n skaitys per Read/Write arba per aplinkos kintamaji - zr. 3 zingsni)

## 2. n8n HTTP mazgas (paprasciausias kelias)
- **Method:** POST
- **URL:** `https://api.groq.com/openai/v1/chat/completions`
- **Authentication:** Generic Credential Type -> Header Auth
  - Name: `Authorization`
  - Value: `Bearer gsk_...`
- **Send Body:** JSON
```
{
  "model": "openai/gpt-oss-120b",
  "messages": [
    { "role": "system", "content": "Atsakyk lietuviskai, trumpai." },
    { "role": "user", "content": "{{ $json.uzduotis }}" }
  ],
  "temperature": 0.3
}
```
- Atsakymas: `{{ $json.choices[0].message.content }}`

## 3. Raktas per aplinkos kintamaji (kad nereiketu rasyti i mazga)
PowerShell (viena karta):
    [Environment]::SetEnvironmentVariable("GROQ_API_KEY","gsk_...","User")
Tada n8n mazge: Header Auth value = `Bearer {{ $env.GROQ_API_KEY }}`
(Pastaba: n8n gali blokuoti `$env` priklausomai nuo `N8N_BLOCK_ENV_ACCESS_IN_NODE`.)

## 4. Kaip patikrinti, kad veikia
Paleisk `11_TESTAS_GROQ.ps1` - jis parodys modeli, atsakyma ir limitus.

## 5. Dažnos klaidos
| Klaida | Priezastis | Sprendimas |
|---|---|---|
| 401 | blogas raktas | sukurti nauja rakta |
| 429 | dienos/minutes limitas | palaukti; mazinti uzklausu dazni |
| 400 model not found | modelio pavadinimas pasikeite | console.groq.com/docs/models |
| Tuscias atsakymas | per ilgas promptas virsija 8k zetonu/min | trumpinti prompta |

## 6. Kiek tai duoda tavo grandinei
- n8n uzduotis -> Groq `gpt-oss-120b` (protingiausias nemokamas variantas).
- Nereikia Ollama, nereikia GPU, nereikia moketi.
- 200 000 zetonu/diena = ~40-60 vidutiniu uzduociu.
