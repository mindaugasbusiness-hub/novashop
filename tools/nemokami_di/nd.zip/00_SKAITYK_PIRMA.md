# NEMOKAMI DI - VISKAS VIENOJE VIETOJE

Sukurta: 2026-11-08 · Cline (relay, K1 = DESKTOP-7LPGR90)
Saltiniai: 4 n8n ataskaitos is `Desktop\n8n_atsakymai` + oficiali dokumentacija, tikrinta 2026-11-08.

## ZYMOS

- **PATIKRINTA** - skaiciu patikrinau oficialioje dokumentacijoje 2026-11-08.
- **NEPATIKRINTA** - tik is n8n ataskaitu (jos generuotos AI, daznai pasenusios) -> pasitikrink pats.

## TRYS KELIAI

| Kelias | Kada | Kaina | Failas |
|---|---|---|---|
| A. Be paskyru | nori offline, be registraciju | 0 EUR, bet letai | `09_OLLAMA.md` |
| B. Nemokama paskyra (API) | nori protingo modelio is karto, be disko | 0 EUR + dienos limitai | `02_GROQ.md` |
| C. Agentai | nori, kad DI pats narsytu | 0 EUR + modelio raktas | `06_BROWSER_USE.md` |

**Rekomendacija tavo PC:** pradėk nuo **B (Groq)** - nesiunti nieko, 200 000 zetonu/diena.
Offline atvejui - A. Narsymo automatizacijai - C su Groq raktu.

## TAVO KOMPIUTERIO RIBOS (2026-11-08)

| | |
|---|---|
| RAM | 7,9 GB |
| CPU | Intel i5-4210M, 2 branduoliai / 4 gijos |
| GPU | Intel HD 4600 (be CUDA) |
| C: laisva | 7,2 GB (po Comet pasalinimo) |

Isvada: **7B ir didesni modeliai netelpa.** Telpa tik 3B (1,9 GB).

## FAILU SARASAS

    00_SKAITYK_PIRMA.md    sis failas
    01_PALYGINIMAS.md      visu variantu lentele
    02_GROQ.md             1-as rinktis: 200k zetonu/d nemokamai
    03_GEMINI.md           Google, ilgas kontekstas
    04_OPENROUTER.md       vienas raktas daug modeliu (50/d nemokamai)
    05_KITI_API.md         Mistral, Cerebras, Cloudflare, Cohere, vienkartiniai kreditai
    06_BROWSER_USE.md      1-as rinktis is agentu (jau idiegtas!)
    07_KITI_AGENTAI.md     Firecrawl, Nanobrowser, OpenHands, BetterClaw
    08_PAIESKOS_API.md     Tavily, Exa, Serper - kad agentas turetu „akis"
    09_OLLAMA.md           visiskai offline, be paskyru
    10_N8N_GROQ.md         kaip prijungti Groq prie n8n
    11_TESTAS_GROQ.ps1     vienas paleidimas - patikrina rakta
    12_SALTINIAI.md        is kur paimta, kas patikrinta

## Ko NEDARYTI

1. Rakto neklijuok i pokalbi, repo ar ekrano nuotrauka - tik i `.env`.
2. Nediek nieko i sistema be atskiro aplanko (viskas, ka diegiau: `C:\Users\M\CLINE\free-ai-venv`).
3. Netrink `BACKUPS` / `BACKUPS_VPS`.
4. Nesiųsk 70B modelio - netilps.

## Kas jau padaryta

- Perskaitytos 4 n8n ataskaitos apie nemokama DI.
- Patikrinti Groq / OpenRouter / Gemini / browser-use / Ollama duomenys.
- `browser-use` 0.13.14 **jau idiegtas** i `C:\Users\M\CLINE\free-ai-venv` (atskiras Python).
- Suvestine atmintyje: `VISKAS\56_2026-11-08_NEMOKAMI_DI.md`.
