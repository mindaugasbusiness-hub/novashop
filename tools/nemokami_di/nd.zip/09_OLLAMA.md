# OLLAMA - visiskai offline, be paskyru (PATIKRINTA)

## Kas tai
Vietinis modeliu serveris: parsisiunti modeli, jis veikia tavo kompiuteryje,
be interneto, be limitu, be saskaitu. API adresas `http://127.0.0.1:11434`.

## Ar telpa tavo PC
| | |
|---|---|
| qwen2.5:3b (Q4_K_M) | **1,9 GB** disko, ~3 GB RAM, 128k kontekstas |
| Greitis (i5-4210M, 2 branduoliai, be GPU) | ~5-10 zetonu/s |

**7B modeliai (4-5 GB) netelpa** - 8 GB RAM ir 2 branduoliai per silpni.

## Kaip idiegti
1. https://ollama.com/download -> Windows installer (~1 GB).
2. PowerShell: `ollama run qwen2.5:3b` (modelis ~1,9 GB).
3. Patikra: `curl http://127.0.0.1:11434/api/tags`

## Kaip naudoti su n8n
HTTP mazgas -> `POST http://127.0.0.1:11434/api/chat`
    { "model": "qwen2.5:3b", "messages": [{"role":"user","content":"..."}] }

## Kam tinka / kam ne
| Tinka | Netinka |
|---|---|
| klasifikavimas, zymejimas | sudetingas samprotavimas |
| trumpi tekstai, juodrasciai | ilgi dokumentai (letai) |
| darbas be interneto | kodas, matematika |
| privatumas (niekas neiseina is PC) | kai reikia greitai |

## Sanaudos
- Diskas ~2,9 GB (programa + modelis) is ~7 GB laisvu.
- RAM ~3 GB, kai modelis uzkrautas.
- **Nenaudok kartu su Groq darbais** - 8 GB RAM per mazai abiem.

**Saltinis:** ollama.com/library/qwen2.5:3b (1,9 GB, Q4_K_M, 3.09B, 2026-11-08)
