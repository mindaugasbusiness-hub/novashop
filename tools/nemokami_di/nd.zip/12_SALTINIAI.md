# SALTINIAI IR KAS PATIKRINTA

## Is kur paimta
`C:\Users\M\Desktop\n8n_atsakymai` (n8n AI ataskaitos, 2026-11-02):

| Failas | Apie ka |
|---|---|
| `ataskaita_2026-11-02_16-01-31.md` | agentai su internetu + nemokami LLM API |
| `ataskaita_2026-11-02_17-01-45.md` | Gemini, Groq, Perplexity, HuggingFace, OpenHands, Tavily |
| `ataskaita_2026-11-02_18-01-45.md` | Browser Use, BetterClaw, BYOK |
| `ataskaita_2026-11-02_16-37-26.md` | n8n HTML ataskaitu taisymas (ne apie DI) |

**Ju kokybe:** mintis teisinga, bet tekstas sugadintas, sumaisyti metai,
dalis skaiciu neparemti -> todel tikrinau is naujo.

## Patikrinta oficialiai (2026-11-08)

| Saltinis | Ka patvirtino |
|---|---|
| console.groq.com/docs/rate-limits | Free plan: 30 RPM / 1 000 RPD / 8 000 TPM / 200 000 TPD (gpt-oss-120b, 20b, qwen3-27b); whisper 20/2 000 |
| openrouter.ai/docs (limits) | `:free` 20 RPM; 50 RPD be kredito; 1 000 RPD su $10 |
| ai.google.dev/gemini-api/docs/rate-limits | Free tier yra; limitai per modeli; RPD vidurnakti PT |
| pypi.org/project/browser-use | versija 0.13.14, Python >= 3.11 |
| ollama.com/library/qwen2.5:3b | 1,9 GB, Q4_K_M, 3.09B parametru |
| tavily.com | yra free plan, bet oficialaus skaiciaus neskelbia |

## Nepatikrinta (tik is n8n ataskaitu)
Mistral, Cerebras, Cloudflare Workers AI, Cohere, Together, Fireworks, SiliconFlow,
Nebius, KIE AI, Amazon Bedrock, Zhipu, Firecrawl, Nanobrowser, OpenHands, BetterClaw,
Steel/Hyperbrowser, Exa, Serper.

## Kada si faila atnaujinti
- Pasikeite limitai (Groq/OpenRouter daznai) - tikrink kas 2-3 men.
- Atsirado nauju nemokamu modeliu (sarasas keiciasi kas savaite).
- Norint, kad Cline atnaujintu automatiskai: pasakyk „atnaujink NEMOKAMI_DI pagal
  oficialia dokumentacija“.
