# KITI NEMOKAMI API TEICIAI (daugiausia NEPATIKRINTA)

> Visi skaiciai is n8n ataskaitu (2026-11-02). Pries naudodamas pasitikrink svetaineje.

| Teikėjas | Kas nemokamai | Kortelė | Kam tinka |
|---|---|---|---|
| **Mistral AI** | nemokamas planas (la free tier) | ne | tekstas, kodas; ES kompanija (GDPR draugiskesne) |
| **Cerebras** | $5 kreditas, gana per 30 d | **TAIP** | labai greitas inference, bet vienkartinis |
| **Cloudflare Workers AI** | ~10 000 neuronu/d | ne | vaizdu atpazinimas, tekstas, serverless |
| **Cohere** | ~1 000 API kvietimu/men (trial) | ne | embeddings, rerank (RAG paieskai!) |
| **Together AI** | vienkartinis kreditas registracijai | ne | atviro kodo modeliai |
| **Fireworks AI** | ~$1 kreditas | ne | greitas inference |
| **SiliconFlow** | ~$1 kreditas | ne | pigus modeliai |
| **Nebius** | ~$1 kreditas | ne | EU infrastruktura |
| **KIE AI** | ~80 kreditu | ne | vaizdai, skirtingi modeliai |
| **Amazon Bedrock** | iki $200 AWS kreditu (naujiems) | ne | Claude/Llama per AWS |
| **Zhipu AI (GLM)** | keli GLM Flash modeliai $0 | ne | kinu/anglu tekstas |

## Kaip rinktis is siu
1. **Nereikia** pradzioje - Groq jau padengia 95 % poreikiu.
2. **Cohere** verta demesio del `rerank` - tai pagerintu tavo RAG kokybe
   (dabar 75 %; rerank daznai pakelia 5-10 punktu).
3. **Bedrock $200** - verta, jei jau naudoji AWS; reikia atsargiai su sanaudomis.
4. Vienkartiniai $1 kreditai - tik bandymui, ne darbui.

## Kaip pasitikrinti paciam
Atidaryk teikėjo puslapyje `pricing` arba `docs` -> ieskok `free tier` /
`rate limits`. Jei nerandi skaiciu per 2 min - greiciausiai siuo metu nera nemokamo lygio.
