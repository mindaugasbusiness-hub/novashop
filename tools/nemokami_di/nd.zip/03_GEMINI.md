# GOOGLE GEMINI (Free tier)

## Kas tai
Google modeliai (Flash, Flash-Lite ir kt.) per Gemini API. Stiprus ilgame kontekste
(ilgi dokumentai, daug teksto is karto) ir neblogai kalba lietuviskai.

## Kiek nemokamai
- Yra **Free tier** (be mokėjimo profilio). Limitai skirtingi pagal modeli:
  RPM (uzklausos/min), TPM (zetonai/min), RPD (uzklausos/diena).
- RPD kvota atsinaujina **vidurnakti Pacific Time** (pas mus ~10:00 ryto).
- **Tikslius savo limitus matai:** https://aistudio.google.com/rate-limit
- **PATIKRINTA:** Free tier egzistuoja ir limitai skiriasi pagal modeli (ai.google.dev, 2026-11-08).
  Konkreciu skaiciu nekopijuoju, nes jie keiciasi ir priklauso nuo projekto.

## Kaip gauti rakta
1. https://aistudio.google.com/apikey
2. Google paskyra -> **Create API key**
3. Irasyk i `.env`: `GEMINI_API_KEY=...`

## Kada rinktis Gemini, o ne Groq
- Reikia **ilgo konteksto** (perskaityti visa dokumenta/vadova).
- Reikia Google paieskos pagrindimo (Grounding with Google Search).
- Groq dienos limitas issemtas (tada persijungti).

## Minusai
- Didesnis delsimas nei Groq.
- Nemokamo lygio kvotos mazesnes nei atrodo.
- Google gali keisti modeliu pavadinimus (daznai atsiranda nauju versiju).

**Saltinis:** ai.google.dev/gemini-api/docs/rate-limits (2026-11-08)
