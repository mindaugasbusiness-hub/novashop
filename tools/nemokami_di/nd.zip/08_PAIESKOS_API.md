# PAIESKOS API - agento „akys" (NEPATIKRINTA)

## Kodel to reikia
LLM zino tik tai, ka ismoko iki mokymo pabaigos. Kad atsakytu apie **siandienos**
kainas, skelbimus ar naujienas - reikia interneto paieskos API.

| Teikėjas | Nemokamai | Stiprybe |
|---|---|---|
| **Tavily** | yra free plan (skaiciaus oficialiai neskelbia; ataskaitose ~1 000/men) | Darytas agentams - grazina jau sutvarkyta turini |
| **Exa** | ~$10/men | Semantine paieska (ne raktazodziai) |
| **Serper** | ~2 500 uzklausu | Google rezultatai pigiai |
| **Firecrawl search** | ~1 000 kreditu/men | Paieska + puslapiu skaitymas kartu |

## Kaip jungiama i n8n
n8n neturi „web search" mazgo - naudojamas HTTP mazgas. Pavyzdys:

    POST https://api.tavily.com/search
    { "api_key": "...", "query": "autoplius automobilis iki 500 eur", "max_results": 5 }

## Rekomendacija
Nepradėk nuo paieskos API. Pirma Groq + Browser Use; jei paaiskės, kad reikia greitos
paieskos be narsymo - tada **Tavily**.

## Svarbu
Paieskos API ≠ modelis: jis grazina nuorodas/tekstą, o atsakyma formuoja LLM.
Reikia abieju: modelio (Groq) + paieskos (Tavily).
