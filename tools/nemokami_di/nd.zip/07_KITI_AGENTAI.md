# KITI AGENTAI (NEPATIKRINTA - is n8n ataskaitu)

| Sprendimas | Kas tai | Nemokamai | Kada rinktis |
|---|---|---|---|
| **Firecrawl** | API, paverciantis puslapi i svaru tekstą + „gyvos" sesijos | ~1 000 kreditu/men | Kai reikia TIK nuskaityti puslapius |
| **Nanobrowser** | Chrome ple tinys - AI valdo tavo narsykle | 100 % | Kai nenori nieko diegti |
| **OpenHands** | Atviro kodo „inzinierius" agentas (Docker) | kodas | Kai DI turi rasyti/tvarkyti KODA |
| **BetterClaw** | Hosted agentas 24/7 (BYOK) | 1 agentas amzinai | Kai nori, kad dirbtu be tavo PC |
| **Steel / Hyperbrowser** | Narsykles backend agentams | bandomieji kreditai | Daug narsykliu vienu metu |
| **OpenAI Operator** | web agentas | NE (~$200/men) | Ne mūsu atvejis |

## Kaip rinktis
1. **Pirmas** - Browser Use (jau idiegtas, nemokamas, lankstus).
2. **Antras** - Firecrawl (daug puslapiu skaitymo, kai Playwright nepatogus).
3. **Trečias** - Nanobrowser (be kodo, tik ple tinyje).

## Ispejimas del zetonu
Vienas narsymo zingsnis = 1-3 LLM uzklausos. Groq limitas 1 000 uzklausu/d
realiai reiskia ~300-500 zingsniu per diena.
