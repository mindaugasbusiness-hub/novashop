# TESTAS_GROQ.ps1 - patikrina, ar Groq raktas veikia (nieko nekeicia, rakto nespausdina)
# Naudojimas:  powershell -ExecutionPolicy Bypass -File 11_TESTAS_GROQ.ps1

$ErrorActionPreference = 'Continue'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

# 1) raktas: is aplinkos arba is ai-stack\.env
$key = $env:GROQ_API_KEY
$saltinis = 'aplinkos kintamasis'
if (-not $key) {
    $envFile = 'C:\Users\M\CLINE\ai-stack\.env'
    if (Test-Path $envFile) {
        $line = Get-Content $envFile -Encoding UTF8 | Where-Object { $_ -match '^\s*GROQ_API_KEY\s*=' } | Select-Object -First 1
        if ($line) { $key = ($line -split '=', 2)[1].Trim().Trim('"').Trim("'"); $saltinis = $envFile }
    }
}
if (-not $key) {
    Write-Host 'NERASTAS GROQ_API_KEY.' -ForegroundColor Yellow
    Write-Host '1) console.groq.com -> API Keys -> Create API Key'
    Write-Host '2) irasyk i C:\Users\M\CLINE\ai-stack\.env:  GROQ_API_KEY=gsk_...'
    exit 1
}
Write-Host ("Raktas rastas (" + $saltinis + "), ilgis " + $key.Length + " simboliu. Reiksme nespausdinama.") -ForegroundColor DarkGray

# 2) uzklausa
$modelis = 'openai/gpt-oss-120b'
$kūnas = @{
    model    = $modelis
    messages = @(
        @{ role = 'system'; content = 'Atsakyk lietuviskai, vienu sakiniu.' },
        @{ role = 'user'; content = 'Pasakyk, kokia siandien diena ir kad Groq veikia.' }
    )
    temperature = 0.2
} | ConvertTo-Json -Depth 6 -Compress

$sw = [Diagnostics.Stopwatch]::StartNew()
try {
    $r = Invoke-WebRequest -Uri 'https://api.groq.com/openai/v1/chat/completions' -Method Post `
        -Headers @{ Authorization = "Bearer $key" } -ContentType 'application/json; charset=utf-8' `
        -Body ([Text.Encoding]::UTF8.GetBytes($kūnas)) -TimeoutSec 60 -UseBasicParsing
} catch {
    $kodas = $_.Exception.Response.StatusCode.value__
    Write-Host ("KLAIDA: HTTP " + $kodas + " - " + $_.Exception.Message) -ForegroundColor Red
    if ($kodas -eq 401) { Write-Host 'Raktas neteisingas arba panaikintas.' }
    if ($kodas -eq 429) { Write-Host 'Dienos/minutes limitas pasiektas - palauk.' }
    if ($kodas -eq 404) { Write-Host 'Modelio pavadinimas pasikeite - ziurek console.groq.com/docs/models' }
    exit 2
}
$sw.Stop()

$d = $r.Content | ConvertFrom-Json
Write-Host ''
Write-Host ('ATSILIEPIMAS (' + $modelis + ', ' + $sw.ElapsedMilliseconds + ' ms):') -ForegroundColor Green
Write-Host ('  ' + $d.choices[0].message.content)
Write-Host ''
Write-Host ('Zetonai: prompt=' + $d.usage.prompt_tokens + ' completion=' + $d.usage.completion_tokens + ' viso=' + $d.usage.total_tokens)
$lim = $r.Headers['x-ratelimit-remaining-requests']
$lim2 = $r.Headers['x-ratelimit-limit-requests']
if ($lim) { Write-Host ("Liko uzklausu siandien: " + $lim + " is " + $lim2) -ForegroundColor DarkGray }
Write-Host ''
Write-Host 'VEIKIA.' -ForegroundColor Green
exit 0
