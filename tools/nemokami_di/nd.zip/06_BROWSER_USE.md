# BROWSER USE - pirmas pasirinkimas is agentu (JAU IDIEGTAS)

## Kas tai
Atviro kodo Python agentas, kuris **valdo narsykle kaip zmogus**: atidaro puslapi,
spaudzia mygtukus, uzpildo formas, skaito lentele, renka duomenis.
Naudoja Playwright (pas tave jau yra 1.63) ir bet kuri LLM per OpenAI-suderinama API.

**PATIKRINTA 2026-11-08:** PyPI versija **0.13.14**, reikia Python >= 3.11 (pas tave 3.12.10).

## Busena tavo kompiuteryje
- Idiegtas i **atskira** aplinka: `C:\Users\M\CLINE\free-ai-venv`
- Sistemos Python **neliestas** (n8n, pultas, RAG dirba kaip dirbo)
- Uzima ~350-400 MB disko

## Ko reikia, kad veiktu
1. **Modelio raktas** - geriausiai Groq (`02_GROQ.md`).
2. Narsykle - Playwright ja turi (arba naudok esama daemona :8099).

## Kaip paleisti
    C:\Users\M\CLINE\free-ai-venv\Scripts\python.exe agentas.py

`agentas.py` mazdaug:

    import asyncio, os
    from browser_use import Agent
    from browser_use.llm import ChatOpenAI
    llm = ChatOpenAI(model="openai/gpt-oss-120b",
                     base_url="https://api.groq.com/openai/v1",
                     api_key=os.environ["GROQ_API_KEY"])
    async def main():
        a = Agent(task="Atidaryk autoplius.lt, rask automobili iki 500 EUR, "
                       "grazink 3 pavadinimus ir kainas", llm=llm)
        print(await a.run())
    asyncio.run(main())

> `llm` klases importo vieta priklauso nuo versijos. Jei neranda - tikrink:
> `python -c "import browser_use, pkgutil; print([m.name for m in pkgutil.iter_modules(browser_use.__path__)])"`

## Pliusai
- Kodas atviras, veikia su tavo narsykle, jokio abonemento.
- Gali dirbti su vietiniu modeliu (Ollama) - tada visiskai be interneto.
- Grazina strukturintus duomenis, ne tik teksta.

## Minusai
- Reikia rakto ir siek tiek programavimo.
- CAPTCHA ir sudetingi puslapiai gali uzstrigti.
- Kiekvienas zingsnis = LLM uzklausa (Groq 200k zetonu/d -> ~40-60 zingsniu/d).

## Kada naudoti
Autoplius / Vinted / Facebook paieska, formu pildymas, duomenu rinkimas i CSV,
kainu stebejimas - tai, ka dabar darai ranka.

**Saltinis:** pypi.org/project/browser-use (0.13.14, 2026-11-08)
