# OPENROUTER (vienas raktas - daug modeliu)

## Kas tai
Tarpininkas: vienu API raktu gauni prieiga prie daugelio modeliu (OpenAI, Anthropic,
Google, Meta, DeepSeek, Qwen...). Modeliai su zenklu `:free` nieko nekainuoja.

## Kiek nemokamai (PATIKRINTA 2026-11-08)
| | |
|---|---|
| Uzklausos/min (`:free`) | **20** |
| Uzklausos/d be kredito | **50** |
| Uzklausos/d su $10 kreditu | **1 000** |
| Kortelė | nereikia |

Ribos bendros visai paskyrai (kuriant papildu raktus daugiau negauni).

## Kada naudoti
- Kai nori **palyginti kelis modelius** vienu raktu.
- Kai reikia modelio, kurio Groq neturi (pvz., Anthropic Claude).
- **Ne** pagrindiniam darbui: 50 uzklausu/diena per mazai automatizacijai.

## Kaip gauti rakta
1. https://openrouter.ai -> sign up
2. **Keys** -> **Create Key**
3. `.env`: `OPENROUTER_API_KEY=...`
4. Modelio pavadinimas uzklausoje, pvz. `meta-llama/llama-3.3-70b-instruct:free`

## Minusai
- `:free` modeliai daznai perkrauti (didesnis delsimas, 429).
- Nemokamu modeliu sarasas keiciasi kas savaite.
- Jei nori rimto naudojimo - reikia $10 (tada 1 000/d).

**Saltinis:** openrouter.ai/docs (limitu sekcija, 2026-11-08)
