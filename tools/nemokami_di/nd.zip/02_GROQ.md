# GROQ - pirmas pasirinkimas (PATIKRINTA 2026-11-08)

## Kas tai
Groq nekuria modeliu - jie **labai greitai juos vykdo** (nuosavi LPU lustai).
Talpina atviro kodo modelius (GPT-OSS, Llama, Qwen, Whisper) ir duoda per API.
Atsakymas ateina per sekundes dalis - greiciau nei OpenAI.

## Kiek nemokamai (Free plan)

| Modelis | Uzkl./min | Uzkl./d | Zetonu/min | Zetonu/d |
|---|---|---|---|---|
| `openai/gpt-oss-120b` | 30 | **1 000** | 8 000 | **200 000** |
| `openai/gpt-oss-20b` | 30 | 1 000 | 8 000 | 200 000 |
| `qwen/qwen3-27b` | 30 | 1 000 | 8 000 | 200 000 |
| `whisper-large-v3` (garsas) | 20 | 2 000 | - | 28 800 s |

**Korteles nereikia.**

## Ka tai reiskia praktiskai
- 200 000 zetonu/d ~ 150 000 zodziu: pakanka n8n briefams, RAG atsakymams, laiskams.
- 1 000 uzklausu/d: kas 5 min = 288/d, lieka daug rezervo.
- Riba pasiekus: HTTP 429 -> palauk arba naudok kita modeli.

## Kaip gauti rakta (2 min)
1. https://console.groq.com
2. Prisijunk (Google arba el. pastu).
3. **API Keys** -> **Create API Key** -> pavadink `n8n`.
4. Nukopijuok (rodomas VIENA karta).
5. Irasyk i `C:\Users\M\CLINE\ai-stack\.env` eilute: `GROQ_API_KEY=gsk_...`

## Kaip naudoti
Paruostas testas: `11_TESTAS_GROQ.ps1`
n8n instrukcija: `10_N8N_GROQ.md`

## Pliusai
- Daug nemokamai, be korteles, labai greitas, OpenAI suderinamas.
- Whisper nemokamai -> garsas i teksta (pravers AUSYS).

## Minusai
- Reikia interneto. Dienos limitas. Duomenys keliauja pas trecia sali.
- Limitus gali keisti -> kartais pasitikrink.

**Saltinis:** console.groq.com/docs/rate-limits (2026-11-08)
